const CACHE_NAME = "bloodlink-shell-v3";
const PRECACHE_ASSETS = [
  "/",
  "/index.html",
  "/manifest.json",
  "/icon-192.png",
  "/splash-512.png",
  "/logo.svg",
  "/apple-touch-icon.png",
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      await Promise.allSettled(
        PRECACHE_ASSETS.map((asset) =>
          fetch(asset, { cache: "reload" })
            .then((res) => {
              if (res.ok) return cache.put(asset, res);
            })
            .catch(() => {})
        )
      );
    })
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.map((key) => {
            if (key !== CACHE_NAME) {
              return caches.delete(key);
            }
          })
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // Never cache API routes
  if (url.pathname.startsWith("/api/")) {
    return;
  }

  // Navigation requests (HTML page loads)
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((networkRes) => {
          // If server returned 429 (Rate exceeded) or 5xx, fallback to cache
          if (networkRes.status === 429 || networkRes.status >= 500) {
            return caches.match("/index.html").then((cached) => cached || networkRes);
          }
          if (networkRes.status === 200) {
            const resClone = networkRes.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put("/index.html", resClone);
            });
          }
          return networkRes;
        })
        .catch(() => {
          return caches.match("/index.html").then((cached) => {
            if (cached) return cached;
            return caches.match("/");
          });
        })
    );
    return;
  }

  // Static assets (JS, CSS, images, fonts)
  if (
    url.pathname.startsWith("/assets/") ||
    url.pathname.endsWith(".js") ||
    url.pathname.endsWith(".css") ||
    url.pathname.endsWith(".png") ||
    url.pathname.endsWith(".svg") ||
    url.pathname.endsWith(".json")
  ) {
    const isImmutableAsset = url.pathname.startsWith("/assets/");
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) {
          // If immutable hashed asset (/assets/*), return immediately without duplicate background network requests
          if (isImmutableAsset) return cached;

          // For loose assets (icons, manifest), revalidate in background
          fetch(req)
            .then((networkRes) => {
              if (networkRes && networkRes.status === 200) {
                const resClone = networkRes.clone();
                caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
              }
            })
            .catch(() => {});
          return cached;
        }

        return fetch(req)
          .then((networkRes) => {
            if (networkRes && networkRes.status === 200) {
              const resClone = networkRes.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
            }
            return networkRes;
          })
          .catch(() => cached);
      })
    );
  }
});
