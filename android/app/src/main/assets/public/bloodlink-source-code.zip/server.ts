import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import os from "os";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let googleModulePromise = null;
async function getGoogle() {
  if (!googleModulePromise) {
    googleModulePromise = import("googleapis").then((m) => m.google);
  }
  return googleModulePromise;
}

function getRequestPayload(req) {
  if (req.body && typeof req.body === "object" && !Array.isArray(req.body) && Object.keys(req.body).length > 0) {
    return req.body;
  }
  if (typeof req.body === "string" && req.body.trim().startsWith("{")) {
    try {
      return JSON.parse(req.body);
    } catch {
      // ignore
    }
  }
  const queryPayload = req.query?.payload;
  if (typeof queryPayload === "string" && queryPayload.trim()) {
    try {
      return JSON.parse(queryPayload);
    } catch {
      // ignore
    }
  }
  return {};
}

async function startServer() {
  const app = express();
  const portArgIndex = process.argv.indexOf("--port");
  const portFromArg = portArgIndex !== -1 ? Number(process.argv[portArgIndex + 1]) : null;
  const PORT =
    portFromArg ||
    Number(process.env.DEFAULT_APP_PORT) ||
    (process.env.PORT && process.env.PORT !== "8080" ? Number(process.env.PORT) : 3000);

  app.use(express.json());
  app.use(express.text({ type: ["text/plain", "application/json"] }));

  // CORS and Access-Control headers to ensure external tools (PWABuilder, Lighthouse, etc.) can fetch manifest, icons, and pages
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, Accept");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Health check endpoint for Cloud Run & auth cache pre-warming
  app.get("/api/health", (_req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    res.status(200).json({ status: "ok", ts: Date.now() });
  });

  // Google Sheets Helper
  const getSheetsClient = async () => {
    const serviceAccountVar = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
    const spreadsheetId = process.env.GOOGLE_SPREADSHEET_ID;

    if (!serviceAccountVar || !spreadsheetId) {
      return null;
    }

    try {
      const google = await getGoogle();
      const credentials = JSON.parse(serviceAccountVar);
      const auth = new google.auth.GoogleAuth({
        credentials,
        scopes: ["https://www.googleapis.com/auth/spreadsheets"],
      });
      return { 
        sheets: google.sheets({ version: "v4", auth }),
        spreadsheetId 
      };
    } catch (e) {
      console.error("Error parsing GOOGLE_SERVICE_ACCOUNT_JSON:", e);
      return null;
    }
  };

  const primaryDbPath = path.join(__dirname, "donors_fallback.json");
  const tmpDbPath = path.join(os.tmpdir(), "donors_fallback.json");

  let dbPath = primaryDbPath;
  try {
    if (!fs.existsSync(primaryDbPath)) {
      fs.writeFileSync(primaryDbPath, JSON.stringify([]));
    } else {
      fs.accessSync(primaryDbPath, fs.constants.W_OK);
    }
  } catch {
    if (!fs.existsSync(tmpDbPath)) {
      try {
        const initialData = fs.existsSync(primaryDbPath) ? fs.readFileSync(primaryDbPath, "utf-8") : "[]";
        fs.writeFileSync(tmpDbPath, initialData);
      } catch {
        fs.writeFileSync(tmpDbPath, "[]");
      }
    }
    dbPath = tmpDbPath;
  }
  const DB_PATH = dbPath;

  const readLocalDonors = () => {
    try {
      const raw = fs.readFileSync(DB_PATH, "utf-8");
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed.filter((d) => d && typeof d === "object" && d.name && d.phone && d.bloodGroup) : [];
    } catch {
      return [];
    }
  };

  const writeLocalDonors = (data) => {
    const validData = Array.isArray(data)
      ? data.filter((d) => d && typeof d === "object" && d.name && d.phone && d.bloodGroup)
      : [];
    try {
      fs.writeFileSync(DB_PATH, JSON.stringify(validData, null, 2));
    } catch (err) {
      console.error("Failed to write local donors fallback:", err);
    }
    if (DB_PATH !== tmpDbPath) {
      try {
        fs.writeFileSync(tmpDbPath, JSON.stringify(validData, null, 2));
      } catch {
        // ignore
      }
    }
  };

  // Simulated OTP storage (in-memory + tmp file backup for serverless/restart resilience)
  const memoryOtps = {};
  const otpFilePath = path.join(os.tmpdir(), "bloodlink_otps.json");
  const getOtps = () => {
    try {
      if (fs.existsSync(otpFilePath)) {
        return { ...memoryOtps, ...JSON.parse(fs.readFileSync(otpFilePath, "utf-8")) };
      }
    } catch {
      // ignore
    }
    return { ...memoryOtps };
  };
  const saveOtp = (phone, otp) => {
    memoryOtps[phone] = otp;
    try {
      const current = getOtps();
      current[phone] = otp;
      fs.writeFileSync(otpFilePath, JSON.stringify(current));
    } catch {
      // ignore
    }
  };
  const deleteOtp = (phone) => {
    delete memoryOtps[phone];
    try {
      const current = getOtps();
      delete current[phone];
      fs.writeFileSync(otpFilePath, JSON.stringify(current));
    } catch {
      // ignore
    }
  };

  app.all("/api/otp/send", (req, res) => {
    const payload = getRequestPayload(req);
    const rawPhone = payload?.phone ?? req.query?.phone;
    const phone = typeof rawPhone === "string" ? rawPhone.trim() : "";
    if (!phone) return res.status(400).json({ error: "Phone number is required" });
    
    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    saveOtp(phone, otp);
    
    console.log(`[OTP DEBUG] Phone: ${phone}, OTP: ${otp}`);
    res.json({ message: "OTP sent successfully", debugOtp: otp });
  });

  app.all("/api/otp/verify", async (req, res) => {
    const payload = getRequestPayload(req);
    const rawPhone = payload?.phone ?? req.query?.phone;
    const rawOtp = payload?.otp ?? req.query?.otp;
    const phone = typeof rawPhone === "string" ? rawPhone.trim() : "";
    const otp = typeof rawOtp === "string" ? rawOtp.trim() : "";
    if (!phone || !otp) return res.status(400).json({ error: "Phone and OTP are required" });
    
    const storedOtp = getOtps()[phone];
    if (storedOtp !== otp) {
      return res.status(400).json({ error: "Invalid OTP" });
    }
    
    deleteOtp(phone); // Clear after use

    // Check if donor exists
    let donor = null;
    let handledBySheets = false;
    const client = await getSheetsClient();
    if (client) {
      try {
        const response = await client.sheets.spreadsheets.values.get({
          spreadsheetId: client.spreadsheetId,
          range: "Donors!A2:M",
        });
        const rows = response.data.values || [];
        const rowIndex = rows.findIndex((row) => String(row[9] || "").trim() === phone && row[1] && row[5]);
        if (rowIndex !== -1) {
          const foundRow = rows[rowIndex];
          donor = {
            id: String(foundRow[0] || Date.now()),
            name: String(foundRow[1] || ""),
            gender: String(foundRow[2] || "Male"),
            dob: String(foundRow[3] || ""),
            weight: Number(foundRow[4]) || 0,
            bloodGroup: String(foundRow[5] || "A+"),
            division: String(foundRow[6] || ""),
            district: String(foundRow[7] || ""),
            upazila: String(foundRow[8] || ""),
            phone: String(foundRow[9] || "").trim(),
            lastDonationDate: String(foundRow[10] || ""),
            timesDonated: Number(foundRow[11]) || 0,
            isActive: foundRow[12] !== "false",
          };

          // Reactivate if inactive
          if (!donor.isActive) {
            const sheetRowIndex = rowIndex + 2;
            await client.sheets.spreadsheets.values.update({
              spreadsheetId: client.spreadsheetId,
              range: `Donors!M${sheetRowIndex}`,
              valueInputOption: "RAW",
              requestBody: { values: [["true"]] },
            });
            donor.isActive = true;
          }
        }
        handledBySheets = true;
      } catch (e) {
        console.error("Sheets error during verify, falling back to local DB:", e);
      }
    }

    if (!handledBySheets) {
      const data = readLocalDonors();
      donor = data.find((d) => String(d.phone || "").trim() === phone) || null;
      if (donor && !donor.isActive) {
        donor.isActive = true;
        writeLocalDonors(data);
      }
    }

    res.json({ verified: true, existingDonor: donor });
  });

  // List active donors
  app.get("/api/donors", async (_req, res) => {
    const client = await getSheetsClient();
    if (client) {
      try {
        const response = await client.sheets.spreadsheets.values.get({
          spreadsheetId: client.spreadsheetId,
          range: "Donors!A2:M", 
        });
        const rows = response.data.values || [];
        const donors = rows
          .filter((row) => row[12] !== "false" && row[1] && row[5] && row[9]) // Only valid active donors
          .map((row) => ({
            id: String(row[0] || Date.now()),
            name: String(row[1] || ""),
            gender: String(row[2] || "Male"),
            dob: String(row[3] || ""),
            weight: Number(row[4]) || 0,
            bloodGroup: String(row[5] || "A+"),
            division: String(row[6] || ""),
            district: String(row[7] || ""),
            upazila: String(row[8] || ""),
            phone: String(row[9] || "").trim(),
            lastDonationDate: String(row[10] || ""),
            timesDonated: Number(row[11]) || 0,
            isActive: row[12] !== "false",
          }));
        return res.json(donors);
      } catch (e) {
        console.error("Sheets API Error (List), falling back to local DB:", e);
      }
    }

    const data = readLocalDonors();
    const activeDonors = data.filter((d) => d.isActive !== false);
    res.json(activeDonors);
  });

  const handleCreateDonor = async (req, res) => {
    const payload = getRequestPayload(req);
    const phone = typeof payload?.phone === "string" ? payload.phone.trim() : "";
    const name = typeof payload?.name === "string" ? payload.name.trim() : "";
    const bloodGroup = typeof payload?.bloodGroup === "string" ? payload.bloodGroup.trim() : "";

    if (!name || !phone || !bloodGroup) {
      return res.status(400).json({ error: "Missing required donor fields (name, phone, bloodGroup)" });
    }

    const donor = {
      id: Date.now().toString(),
      name,
      gender: payload.gender || "Male",
      dob: payload.dob || "",
      weight: Number(payload.weight) || 0,
      bloodGroup,
      division: payload.division || "",
      district: payload.district || "",
      upazila: payload.upazila || "",
      phone,
      lastDonationDate: payload.lastDonationDate || "",
      timesDonated: Number(payload.timesDonated) || 0,
      isActive: true,
    };

    const client = await getSheetsClient();
    if (client) {
      try {
        const row = [
          donor.id,
          donor.name,
          donor.gender,
          donor.dob,
          donor.weight,
          donor.bloodGroup,
          donor.division,
          donor.district,
          donor.upazila,
          donor.phone,
          donor.lastDonationDate,
          donor.timesDonated,
          "true"
        ];

        await client.sheets.spreadsheets.values.append({
          spreadsheetId: client.spreadsheetId,
          range: "Donors!A1",
          valueInputOption: "RAW",
          requestBody: {
            values: [row],
          },
        });
        return res.json(donor);
      } catch (e) {
        console.error("Sheets API Error (Create), falling back to local DB:", e);
      }
    }

    const data = readLocalDonors();
    const existingIdx = data.findIndex((d) => String(d.phone || "").trim() === phone);
    if (existingIdx !== -1) {
      data[existingIdx] = { ...data[existingIdx], ...donor, id: data[existingIdx].id || donor.id };
      writeLocalDonors(data);
      return res.json(data[existingIdx]);
    }
    data.push(donor);
    writeLocalDonors(data);
    res.json(donor);
  };

  app.all("/api/donors/register", handleCreateDonor);
  app.post("/api/donors", handleCreateDonor);

  const handleUpdateDonor = async (req, res) => {
    const phone = (req.params.phone || "").trim();
    const updates = getRequestPayload(req);
    if (!phone) return res.status(400).json({ error: "Phone is required" });

    const client = await getSheetsClient();
    if (client) {
      try {
        const response = await client.sheets.spreadsheets.values.get({
          spreadsheetId: client.spreadsheetId,
          range: "Donors!A2:M",
        });
        const rows = response.data.values || [];
        const rowIndex = rows.findIndex((row) => String(row[9] || "").trim() === phone);
        
        if (rowIndex === -1) return res.status(404).json({ error: "Donor not found" });

        const sheetRowIndex = rowIndex + 2;
        const currentRow = rows[rowIndex];

        const existingDonor = {
          id: String(currentRow[0] || Date.now()),
          name: String(currentRow[1] || ""),
          gender: String(currentRow[2] || "Male"),
          dob: String(currentRow[3] || ""),
          weight: Number(currentRow[4]) || 0,
          bloodGroup: String(currentRow[5] || "A+"),
          division: String(currentRow[6] || ""),
          district: String(currentRow[7] || ""),
          upazila: String(currentRow[8] || ""),
          phone: String(currentRow[9] || "").trim(),
          lastDonationDate: String(currentRow[10] || ""),
          timesDonated: Number(currentRow[11]) || 0,
          isActive: currentRow[12] !== "false",
        };

        const mappings = {
          name: "B", gender: "C", dob: "D", weight: "E", bloodGroup: "F",
          division: "G", district: "H", upazila: "I", phone: "J", 
          lastDonationDate: "K", timesDonated: "L", isActive: "M"
        };

        const updatePromises = Object.keys(updates).map(key => {
          if (!mappings[key]) return null;
          const value = key === "isActive" ? String(updates[key]) : updates[key];
          return client.sheets.spreadsheets.values.update({
            spreadsheetId: client.spreadsheetId,
            range: `Donors!${mappings[key]}${sheetRowIndex}`,
            valueInputOption: "RAW",
            requestBody: { values: [[value]] },
          });
        }).filter(Boolean);

        await Promise.all(updatePromises);
        
        return res.json({ ...existingDonor, ...updates });
      } catch (e) {
        console.error("Sheets API Error (Update), falling back to local DB:", e);
      }
    }

    const data = readLocalDonors();
    const donorIndex = data.findIndex((d) => String(d.phone || "").trim() === phone);
    if (donorIndex === -1) return res.status(404).json({ error: "Donor not found" });

    data[donorIndex] = { ...data[donorIndex], ...updates };
    writeLocalDonors(data);
    res.json(data[donorIndex]);
  };

  app.all("/api/donors/update/:phone", handleUpdateDonor);
  app.patch("/api/donors/:phone", handleUpdateDonor);

  const distPath = fs.existsSync(path.join(__dirname, "dist"))
    ? path.join(__dirname, "dist")
    : path.join(process.cwd(), "dist");
  const indexHtmlPath = path.join(distPath, "index.html");
  const isDevScript =
    process.env.npm_lifecycle_event === "dev" ||
    process.execArgv.some((arg) => arg.includes("tsx")) ||
    process.argv.some((arg) => arg.includes("tsx"));
  const useStaticDist =
    (process.env.NODE_ENV === "production" || !isDevScript) &&
    fs.existsSync(indexHtmlPath);

  if (!useStaticDist) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const assetsDir = path.join(distPath, "assets");
    if (fs.existsSync(assetsDir)) {
      app.use("/assets", express.static(assetsDir, { maxAge: "30d", immutable: true }));
    }
    app.use(express.static(distPath, { maxAge: "1d", etag: true }));
    app.get("*", (_req, res) => {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.sendFile(indexHtmlPath);
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT} (static=${useStaticDist})`);
  });
}

process.on("unhandledRejection", (reason) => {
  console.error("Unhandled promise rejection in server:", reason);
});
process.on("uncaughtException", (err) => {
  console.error("Uncaught exception in server:", err);
});

startServer();
